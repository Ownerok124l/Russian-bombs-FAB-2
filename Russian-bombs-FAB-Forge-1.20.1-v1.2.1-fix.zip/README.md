# Russian-bombs (FAB)

Minecraft Java 1.20.1 / Minecraft Forge 47.2.0 / Java 17

## Included
- FAB-100
- FAB-500
- FAB-3000
- Throwable bomb projectile with different in-game explosion strengths
- Russian and English item names
- Simple inventory textures

## Build
1. Install a Java 17 JDK.
2. Install Minecraft Forge 1.20.1 (47.2.0) in your launcher for testing.
3. Open this folder in IntelliJ IDEA or Eclipse as a Gradle project.
4. Run the Gradle task `build`.
5. The mod jar will be in `build/libs/`.

This is a starter development project. It has not been compiled in this environment.
The bombs are fictional Minecraft gameplay items; explosion sizes are game balance values,
not real-world specifications. Large explosions can damage blocks and entities.

## Update 1.1.0 — custom item geometry
The three bomb items now use custom block-model geometry with a long casing and four tail fins.
The projectile renderer reuses the item model, so the same geometry is shown while thrown.
These are stylized Minecraft models rather than detailed real-world replicas.

## Update 1.2.0 — effects and audio
- Flight smoke trail (smoke and campfire smoke particles).
- Explosion smoke burst.
- Throw sound using a vanilla Minecraft trident sound.
- Explosion sound using the vanilla generic explosion sound.
- The projectile uses its custom item geometry and vanilla projectile orientation for in-flight motion.
- The in-game explosion remains a Minecraft effect and is not a real-world simulation.

## Update 1.2.1 — Forge compilation fix
Changed entity NBT serialization overrides to public visibility to match the Minecraft 1.20.1 API.
