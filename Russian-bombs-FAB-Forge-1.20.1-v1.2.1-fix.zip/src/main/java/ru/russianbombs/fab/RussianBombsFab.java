package ru.russianbombs.fab;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(RussianBombsFab.MODID)
public class RussianBombsFab {
    public static final String MODID = "russianbombsfab";

    public RussianBombsFab() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITY_TYPES.register(bus);
    }
}
