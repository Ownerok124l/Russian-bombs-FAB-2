package ru.russianbombs.fab;

import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class FabBombItem extends Item {
    private final float explosionPower;

    public FabBombItem(float explosionPower, Properties properties) {
        super(properties);
        this.explosionPower = explosionPower;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            FabBombEntity bomb = new FabBombEntity(ModEntities.FAB_BOMB.get(), player, level, explosionPower);
            bomb.shootFromRotation(player, player.getXRot(), player.getYRot(), -15.0F, 1.35F, 0.5F);
            level.addFreshEntity(bomb);
            level.playSound(null, player.blockPosition(), SoundEvents.TRIDENT_THROW,
                    SoundSource.PLAYERS, 0.8F, 0.75F + level.random.nextFloat() * 0.2F);
            if (!player.getAbilities().instabuild) {
                stack.shrink(1);
            }
        }
        player.awardStat(Stats.ITEM_USED.get(this));
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
