package ru.russianbombs.fab;

import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, RussianBombsFab.MODID);

    public static final RegistryObject<Item> FAB_100 = ITEMS.register("fab_100",
            () -> new FabBombItem(3.0F, new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> FAB_500 = ITEMS.register("fab_500",
            () -> new FabBombItem(6.0F, new Item.Properties().stacksTo(8)));
    public static final RegistryObject<Item> FAB_3000 = ITEMS.register("fab_3000",
            () -> new FabBombItem(10.0F, new Item.Properties().stacksTo(1)));
}
