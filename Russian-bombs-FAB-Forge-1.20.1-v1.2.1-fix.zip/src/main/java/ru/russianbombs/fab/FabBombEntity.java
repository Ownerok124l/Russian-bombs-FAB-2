package ru.russianbombs.fab;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;

public class FabBombEntity extends ThrowableItemProjectile {
    private float explosionPower = 3.0F;
    private int flightTicks = 0;

    public FabBombEntity(EntityType<? extends FabBombEntity> type, Level level) {
        super(type, level);
    }

    public FabBombEntity(EntityType<? extends FabBombEntity> type, LivingEntity owner,
                         Level level, float explosionPower) {
        super(type, owner, level);
        this.explosionPower = explosionPower;
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.FAB_100.get();
    }

    @Override
    public void tick() {
        super.tick();
        flightTicks++;

        // A visible smoke trail follows the bomb during flight.
        if (level().isClientSide && flightTicks % 2 == 0) {
            level().addParticle(ParticleTypes.SMOKE,
                    getX(), getY() - 0.12D, getZ(),
                    0.0D, -0.025D, 0.0D);
            if (flightTicks % 6 == 0) {
                level().addParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE,
                        getX(), getY() - 0.18D, getZ(),
                        0.0D, -0.015D, 0.0D);
            }
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!level().isClientSide) {
            // Vanilla explosion sound plus a short impact cue.
            level().playSound(null, blockPosition(), SoundEvents.GENERIC_EXPLODE,
                    SoundSource.BLOCKS, 3.0F, 0.85F + random.nextFloat() * 0.25F);

            // Large visual burst. The actual blast remains a Minecraft gameplay effect.
            level().explode(this, getX(), getY(), getZ(), explosionPower,
                    Level.ExplosionInteraction.TNT);

            for (int i = 0; i < 24; i++) {
                double dx = (random.nextDouble() - 0.5D) * 1.8D;
                double dy = random.nextDouble() * 1.3D;
                double dz = (random.nextDouble() - 0.5D) * 1.8D;
                level().addParticle(ParticleTypes.LARGE_SMOKE,
                        getX() + dx, getY() + dy, getZ() + dz,
                        dx * 0.15D, 0.08D + random.nextDouble() * 0.12D, dz * 0.15D);
            }
            discard();
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putFloat("ExplosionPower", explosionPower);
        tag.putInt("FlightTicks", flightTicks);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("ExplosionPower")) {
            explosionPower = tag.getFloat("ExplosionPower");
        }
        flightTicks = tag.getInt("FlightTicks");
    }
}
